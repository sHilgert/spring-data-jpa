package br.fatec.atividade07.service;

import br.fatec.atividade07.model.Categoria;

public interface CategoriaService {
	
	public Categoria getCategoryById(Long id);
}
